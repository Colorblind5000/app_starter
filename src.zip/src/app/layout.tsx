// Src/layout.tsx
import React from 'react';
import Link from 'next/link';
import './globals.css'; // Opret en css fil for styling

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <div style={{ display: 'flex' }}>
          <nav style={{ width: '200px', position: 'fixed', right: '0', height: '100vh', padding: '1rem', backgroundColor: '#f3f4f6' }}>
            <ul style={{ listStyle: 'none', padding: 0 }}>
              <li><Link href="/">Home</Link></li>
              <li><Link href="/about">About</Link></li>
              {/* Tilføj flere links her */}
            </ul>
          </nav>
          <main style={{ marginRight: '200px', padding: '1rem', width: '100%' }}>
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
