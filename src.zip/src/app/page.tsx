// Src/page.tsx
export default function HomePage() {
  return (
    <div>
      <h1>Welcome to My SaaS App</h1>
      <p>This is the homepage of our SaaS app.</p>
    </div>
  );
}
